package com.cts.interceptors;

import java.io.Serializable;
import java.util.Date;
import java.util.Iterator;

import org.hibernate.EmptyInterceptor;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.Type;

import com.cts.entities.Location;
import com.cts.entities.LocationTracker;
import com.cts.resources.HibernateUtil;

public class LocationInterceptor extends EmptyInterceptor{
	private boolean isActivity;
	private String message;
	

	@Override
	public int[] findDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState,
			String[] propertyNames, Type[] types) {
		// TODO Auto-generated method stub
		System.out.println("Flushing find Dirty.......");
		return super.findDirty(entity, id, currentState, previousState, propertyNames, types);
	}

	@Override
	public void onDelete(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
		// TODO Auto-generated method stub
		System.out.println("Deleting.......");
		super.onDelete(entity, id, state, propertyNames, types);
	}

	@Override
	public boolean onFlushDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState,
			String[] propertyNames, Type[] types) {
		// TODO Auto-generated method stub
		System.out.println("Flushing on flush dirty.......");
		return super.onFlushDirty(entity, id, currentState, previousState, propertyNames, types);
	}

	@Override
	public boolean onLoad(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
		// TODO Auto-generated method stub
		System.out.println("Loading.....");
		return super.onLoad(entity, id, state, propertyNames, types);
	}

	@Override
	public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
		// TODO Auto-generated method stub
		System.out.println("Saving.....");
		if(entity instanceof Location )
		{
			Location loc=(Location)entity;
			isActivity=true;
			message="Inserted"+loc.getLocationId();
			return isActivity;
			
		}
		else
			return isActivity;
		
		//return super.onSave(entity, id, state, propertyNames, types);
	}

	@Override
	public void postFlush(Iterator entities) {
		// TODO Auto-generated method stub
		System.out.println("Flushing Post Flush......");
		System.out.println(isActivity);
		if(isActivity)
		{
			SessionFactory factory=HibernateUtil.getSessionFactory();
			Session session=factory.openSession();
			session.beginTransaction();
			LocationTracker tracker =new LocationTracker();
			tracker.setActivity(message);
            tracker.setActivityDate(new Date());
            session.save(tracker);
            isActivity=false;
            session.getTransaction().commit();
			session.close();
		}
		
		
		
		super.postFlush(entities);
	}

	@Override
	public void preFlush(Iterator entities) {
		// TODO Auto-generated method stub
		System.out.println("Flushing pre flush.......");
		
		
		super.preFlush(entities);
	}

}
