

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.cts.booking.entity.Event;
import com.cts.booking.entity.Location;
/**
 * 
 * @author pejjac
 * //4)	Create One to Many relationship with Location and Event entity classes
 *
 */
 

public class LocationEventOneToManyClient {

	public static void main(String[] args) {
		SessionFactory factory = util.HibernateUtil.getSessionFactory();

		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();

		Location location = new Location();
		location.setLocationId(53);
		location.setLocationName("Delhi");

		Set<Event> events = new HashSet<Event>();
		Event event1 = new Event();
		event1.setEventId(2);
		event1.setEventName("booking");
		event1.setEventDate(new Date());
		event1.setLocationId(53);
		event1.setTicketsAvailable(10);
		events.add(event1);
		
		Event event2 = new Event();
		event2.setEventId(3);
		event2.setEventName("booking1");
		event2.setEventDate(new Date());
		event2.setLocationId(53);
		event2.setTicketsAvailable(11);
		events.add(event2);
		
		location.setEventChildren(events);
		session.save(location);
		transaction.commit();

		System.out.println("Events per Delhi location = "+location.getEventChildren().size());
		session.close();

	}

}
