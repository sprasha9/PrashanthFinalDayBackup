package com.cts.dao;

import org.hibernate.Cache;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cts.entities.Booking;
import com.cts.entities.Customer;
import com.cts.entities.Event;
import com.cts.entities.Location;
import com.cts.resources.HibernateUtil;

public class BookingDao {
private SessionFactory factory;
private Session session;
private Location location;
private Event event;
private Customer customer;

public BookingDao()
{
	factory=HibernateUtil.GetFactory();
}

//Insert Location
public void InsertLoaction(Location loc) {
	location=loc;
	session=factory.openSession();
	session.beginTransaction();
	try {
		session.save(location);
		session.getTransaction().commit();
	} catch (HibernateException e) {
		// TODO: handle exception
		session.getTransaction().rollback();
	}
	
}

//Insert Event
public void InsertEvent(Event eve,int locationid) {
	event =eve;
	session=factory.openSession();
	Location result=(Location) session.get(Location.class, locationid);
	session.beginTransaction();
	try {
		eve.setLocation(result);
		session.persist(event);
		session.getTransaction().commit();
	} catch (HibernateException e) {
		// TODO: handle exception
		session.getTransaction().rollback();
	}
}

//Inserrt Booking
public void InsertBooking(Booking booking) {
	
}


//Insert Customer
public void InsertCustomer(Customer customer) {
	
}

public boolean TestSecondLevelcache()
{
	factory= HibernateUtil.GetFactory();
	session= factory.openSession();
	Location location =(Location)session.load(Location.class,105);
	System.out.println("Check First level Cache before Evict");
	System.out.println("Status of Object" + session.contains(location));
	session.evict(location);
	System.out.println("Check First level Cache After Evict");
	System.out.println("Status of Object" + session.contains(location));
	Cache cache = factory.getCache();
	System.out.println("Check First level Cache After Evict");
	System.out.println("Status of Object" +cache.containsEntity(Location.class,105));
	return cache.containsEntity(Location.class, 105);
}
}
