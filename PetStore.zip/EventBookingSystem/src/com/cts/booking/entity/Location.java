package com.cts.booking.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Location_v")
public class Location {

	@Id
	@Column(name="location_id")
	private int locationId;

	
	public int getLocationId() {
		return locationId;
	}

	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
    

	@Column(name="location_name")
	private String locationName;
	
	@OneToMany(fetch=FetchType.LAZY, targetEntity=Event.class, cascade=CascadeType.ALL)
     @JoinColumn(name = "LOCATION_ID", referencedColumnName="location_id")
	private Set eventChildren;


	public Set getEventChildren() {
		return eventChildren;
	}

	public void setEventChildren(Set eventChildren) {
		this.eventChildren = eventChildren;
	}
	

}
