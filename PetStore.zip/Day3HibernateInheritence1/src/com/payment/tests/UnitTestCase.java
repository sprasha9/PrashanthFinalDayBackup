package com.payment.tests;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.payment.beans.CreditCard;
import com.payment.beans.Payment;
import com.payment.dao.DaoManager;

public class UnitTestCase {
DaoManager dm;
	@Before
	public void setUp() throws Exception {
		dm=new DaoManager();
	}

	@After
	public void tearDown() throws Exception {
	}
/*
	@Test
	public void test() {
		//fail("Not yet implemented");
		Payment pay=new Payment();
		pay.setAmount(7899);
		pay.setPay_id(0006);
		pay.setDOT(new Date(016,05,28));
		assertTrue(dm.AddPayment(pay));
	}
*/
	@Test
	public void testCreditCard() {
		//fail("Not yet implemented");
		CreditCard ccobj=new CreditCard();
		ccobj.setAmount(1500);
		ccobj.setCustomer_id(574207);
		ccobj.setCcCVV(236);
		ccobj.setCcEMI(true);
		ccobj.setCreditCardNo(000022003);
		ccobj.setCcExpDate(new Date(92, 05, 28));
		ccobj.setPay_id(00064);
		ccobj.setDOT(new Date(92, 05, 28));
		ccobj.setCcName("Prashanth Sekar");
		assertTrue(dm.AddPayment(ccobj));
	}
}
