package com.prash.beans;

public class Room {
	private int roomno;
	private String location;
	private int capacity;
	private boolean machine_avl;
	private boolean proj_avl;
	
	public int getRoomno() {
		return roomno;
	}
	public void setRoomno(int roomno) {
		this.roomno = roomno;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public boolean isMachine_avl() {
		return machine_avl;
	}
	public void setMachine_avl(boolean machine_avl) {
		this.machine_avl = machine_avl;
	}
	public boolean isProj_avl() {
		return proj_avl;
	}
	public void setProj_avl(boolean proj_avl) {
		this.proj_avl = proj_avl;
	}

}
