package com.prash.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;

@Entity
@Table(name="Player")
public class Player {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="playerId")
	private int playerId;
@Column(name="playerName")
	private String pname;
@ManyToOne(fetch=FetchType.LAZY)
@JoinColumn(name="TeamId",nullable=false)
	private Team team;


	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public Team getTm() {
		return team;
	}
	public void setTm(Team tm) {
		this.team = tm;
	}
	
	
}
