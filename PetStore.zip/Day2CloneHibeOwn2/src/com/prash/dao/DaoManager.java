package com.prash.dao;

import java.util.List;

import javax.management.Query;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.prash.beans.Course;
import com.prash.beans.Player;
import com.prash.beans.Team;
import com.prash.beans.Trainee;
import com.prash.resources.HibernateUtil;

public class DaoManager {
	private SessionFactory factory;
	private Session session;

	public DaoManager()
	{
		factory=HibernateUtil.GetFactory();
	}
	
	public boolean AddTeam_Player(Team tm,List<Player> playerList) {
		boolean status=false;
		session=factory.openSession();
		session.beginTransaction();
		try {
			tm.setPlist(playerList);
			session.save(tm);
			session.getTransaction().commit();
			status=true;
		} catch (Exception e) {
			// TODO: handle exception
			session.getTransaction().rollback();
		}
		
		
		return status;
		
	}
	
	
	public List<Team> getAll_team_players()
	{
		//boolean status=false;
		session=factory.openSession();
		return session.createQuery("from Team").list(); 
		
	}
	
	
	
	
	public boolean Add_Trainee_course(List<Trainee> tlist,List<Course> clist)
	{
		boolean status=false;
		session=factory.openSession();
		session.beginTransaction();
		try {
			for (Trainee trainee : tlist) {
				trainee.setCourseList(clist);
				session.save(trainee);
				
			}
			session.getTransaction().commit();
			status=true;
			
		} catch (HibernateException e) {
			
			
			// TODO: handle exception
		}
		return status;
		
	}
}
