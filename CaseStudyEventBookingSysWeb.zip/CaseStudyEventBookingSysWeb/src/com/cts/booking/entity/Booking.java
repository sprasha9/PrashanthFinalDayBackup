package com.cts.booking.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="BOOKING_MASTER")
public class Booking {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="CUST_ID")
	private int custId;
@Column(name="EVENT_ID")	
	private int eventId;
	

//create custId and eventId as composite primary keys and change the class structure accordingly



@Column(name="TICKETS_BOOKED")	
	private int ticketsBooked;
@Column(name="AMOUNT")	
	private float amount;
public int getCustId() {
	return custId;
}
public void setCustId(int custId) {
	this.custId = custId;
}
public int getEventId() {
	return eventId;
}
public void setEventId(int eventId) {
	this.eventId = eventId;
}
public int getTicketsBooked() {
	return ticketsBooked;
}
public void setTicketsBooked(int ticketsBooked) {
	this.ticketsBooked = ticketsBooked;
}
public float getAmount() {
	return amount;
}
public void setAmount(float amount) {
	this.amount = amount;
}


}
