package com.cts.entites;

import java.util.Date;

import org.hibernate.annotations.Entity;
import org.hibernate.annotations.Table;

@Entity
@Table(name = "LocationTracker")

public class LocationTracker {
	private trackerId;
	private String activity;
	private Date activityDate;
		


}
