package com.prash.beans;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="Book")
public class Book {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ISBN")
	private int ISBN;
	@Column(name="book_name")
	private String Name;
	@Temporal(TemporalType.DATE)
	@Column(name="dop")
	private Date dop;
	@OneToOne(mappedBy="book",cascade=CascadeType.ALL)
	private Author auth;
	
	
	public Author getAuth() {
		return auth;
	}


	public void setAuth(Author auth) {
		this.auth = auth;
	}


	public int getISBN() {
		return ISBN;
	}
	
	
	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}
	
	
	public String getName() {
		return Name;
	}
	
	
	public void setName(String name) {
		Name = name;
	}
	public Date getDop() {
		return dop;
	}
	
	
	public void setDop(Date dop) {
		this.dop = dop;
	}
	
}
