package com.payment.beans;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Table;

@Entity
@Table(name="CTS_Manager")

public class CTS_Manager extends Employee{
@Column(name="nop")
	private int n_Projects;
@Column(name="LeaveApproval")
	private boolean leaveApproval;
	
	
	public int getN_Projects() {
		return n_Projects;
	}
	public void setN_Projects(int n_Projects) {
		this.n_Projects = n_Projects;
	}
	public boolean isLeaveApproval() {
		return leaveApproval;
	}
	public void setLeaveApproval(boolean leaveApproval) {
		this.leaveApproval = leaveApproval;
	}
	
}
