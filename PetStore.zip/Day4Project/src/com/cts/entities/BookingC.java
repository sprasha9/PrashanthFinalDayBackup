package com.cts.entities;
import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.cts.entities.Customer;
import com.cts.entities.Event;

@Embeddable
public class BookingC implements Serializable{
@OneToOne
@JoinColumn(name="cust_id")
	private Customer customer;
@OneToOne
@JoinColumn(name="Event_ID")
	private Event event;
}
