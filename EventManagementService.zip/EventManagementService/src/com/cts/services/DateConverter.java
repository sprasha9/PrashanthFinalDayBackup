package com.cts.services;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.cts.entities.Employee;



@Path("/DateConverter") //step 2
public class DateConverter 
{
	
	//creste sub path 5th step
			@GET
			@Path("/Format/{year}/{month}/{day}")
     //3 step create method
			                  //step 6 (@PathParam("year")int year,@PathParam("month")int month,@PathParam("day") int day)
	public Response FormatDate(@PathParam("year")int year,@PathParam("month")int month,@PathParam("day") int day)
	{
		SimpleDateFormat format=new SimpleDateFormat("yyyy/MMM/dd");
	    Date d=new Date(year-1900,month-1,day);
	    String fdate=format.format(d);
		
		
		//create response 4th step
		return Response.status(200).header("Acess-control-Allow-Orgin", "*")
				.header("Access-Control-Allow-Headers","orgin,content-type,accept,authorization")
				.header("Access-Control-Allow-Credentials", true)
				.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
				.header("Access-Control-Max-Age","1209600" )
				.entity(fdate)
				.build();
	}

			@GET
			@Path("/EmployeeInfo")
	public Response getEmployeeInfo(@QueryParam("EmployeeId")int EmployeeId, 
			@QueryParam("Name")String Name,
			@QueryParam("Skillset")List<String> SkillSet) 
			{
				Employee emp=new Employee();
				emp.setEmpid(EmployeeId);
				emp.setName(Name);
				emp.setSkillset(SkillSet);
				return Response.status(200).header("Acess-control-Allow-Orgin", "*")
						.header("Access-Control-Allow-Headers","orgin,content-type,accept,authorization")
						.header("Access-Control-Allow-Credentials", true)
						.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
						.header("Access-Control-Max-Age","1209600" )
						.entity(emp)
						.build();
	}
							
			
}
