package com.cts.booking.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.cts.CustomerMaster;

@Entity
@Table(name="Event_master")
public class Event implements Serializable{

	@Id
	@Column(name="event_id")
	private int eventId;

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}



	public Date getEventDate() {
		return eventDate;
	}

	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}

	public int getTicketsAvailable() {
		return ticketsAvailable;
	}

	public void setTicketsAvailable(int ticketsAvailable) {
		this.ticketsAvailable = ticketsAvailable;
	}

	public int getLocationId() {
		return locationId;
	}

	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}
	
	@ManyToMany(
	        cascade = {CascadeType.PERSIST, CascadeType.MERGE},
	        mappedBy = "events",
	        targetEntity = com.cts.CustomerMaster.class
	    )
	    private Set<CustomerMaster> customers=new HashSet<CustomerMaster>();

	public Set<CustomerMaster> getCustomers() {
		return customers;
	}

	public void setCustomers(Set<CustomerMaster> customers) {
		this.customers = customers;
	}

	@Column(name="event_name")
	private String eventName;
	@Column(name="event_date")
	private Date eventDate;
	@Column(name="tickets_available")
	private int ticketsAvailable;
	@Column(name="location_id")
	private int locationId;
	
}
