package com.cts.entities;

public class ExistingCustomer extends Customer{
	private int points;
	
	
	public int getPoints() {
		return points;
	}

	public void setPoints(int points) {
		this.points = points;
	}

	
	
	
}
