import com.cts.EventManager;
/**
 * 
 * @author pejjac
 *
 */

//6)	Create a composite key in the booking master table  and Create a many to many relationship with the Customer and the Event entity  - [COMPLEX]
public class CustomerEventManyToManyClient{
public static void main(String []a){
	  EventManager sc=new  EventManager();
	  sc.insertEvents(10,"Event1");
	  sc.insertEvents(15,"Event2");
	  sc.insertCustomers(20, "name1", "cust_address1");
	  sc.insertCustomers(21, "name2", "cust_address2");
	  sc.insertCustomers(23, "name3", "cust_address3");
	  sc.addCustomers_to_Event(1, 30, 10);
	  sc.addEvents_to_Customer(1, 20, 20);
	 }}
