package com.cts.booking.entity;

public class ExistingCustomer extends Customer{
//This class would adopt inheritance strategy    

}
