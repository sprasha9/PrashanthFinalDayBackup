package com.cts.util;

import org.hibernate.Cache;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.cts.entities.Location;
import com.cts.resources.HibernateUtil;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session=sessionFactory.openSession();		
	/*	System.out.println("retrieve from first level cache.....");
		Location location= (Location) session.load(Location.class, 1);
		System.out.println(location.getLocationName());
		System.out.println("Before Clear"+session.contains(location));
		session.evict(location);
		System.out.println("After Clear"+session.contains(location));
		System.out.println("retrieve from second level cache.....");
		Cache cache = sessionFactory.getCache();
		System.out.println(cache.containsEntity(Location.class, 1));
		location=(Location) session.load(Location.class, 1);
		System.out.println(location.getLocationName());*/
	
		session.beginTransaction();
		try
		{
			Location location=new Location();
			location.setLocationName("SEZ");
			session.save(location);
			session.getTransaction().commit();
		}
		catch(HibernateException hib)
		{
			session.getTransaction().rollback();
		}
		session.close();
	}

}
