package com.prash.utility;



import java.util.Date;
import java.util.Iterator;

import com.prash.beans.Address;
import com.prash.beans.Customer;
import com.prash.dao.DaoManager;

public class TestApp {
/*
	public static void main(String[] args) {
	DaoManager dm=new DaoManager();
	Address address=new Address();
	address.setAddStreet("N.Shop Stret");
	address.setAddcity("chennai");
	Customer cus=new Customer();
	cus.setCusname("Prashanth");
	cus.setCusdob(new Date(05, 05, 28));
	dm.AddCustomer_Adress(cus, address);
}
*/
	
	public static void main(String[] args) {
		DaoManager dManager=new DaoManager();
		Iterator itr=dManager.GetAll().iterate();
		while(itr.hasNext())
		{
			//System.out.println(itr.next());
			Object[] obj=(Object[]) itr.next();
			System.out.println(obj[0]+" "+obj[1]+" "+ obj[2]+" "+obj[3]);
		}
	}

}
