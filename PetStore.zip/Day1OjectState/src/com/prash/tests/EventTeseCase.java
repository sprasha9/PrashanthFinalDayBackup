package com.prash.tests;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.prash.beans.Event;
import com.prash.beans.EventKey;
import com.prash.dao.EventManager;

public class EventTeseCase {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		EventManager eventManager=new EventManager();
		EventKey eventKey=new EventKey();
		eventKey.setEventId(20);
		eventKey.setTrainerId(669);
		
		Event event=new Event();
		event.setEventid(eventKey);
		event.setEventduration(5);
		event.setEventlocation("chennai");
		event.setEventname("My Hibe Training");
		//eventManager.AddEvent(event);
		assertTrue(eventManager.AddEvent(event));
	}

}
