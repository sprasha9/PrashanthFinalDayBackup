package com.cts;
import java.util.*;
import javax.persistence.*;

@Entity
public class CustomerMaster {

	@Id
	protected int custId;

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}

	@Column
	protected String custName;
	@Column
	protected String custAddress;

	@ManyToMany(targetEntity = com.cts.EventMaster.class, cascade = {
			CascadeType.PERSIST, CascadeType.MERGE })
	@JoinTable(name = "Bookingc", joinColumns = @JoinColumn(name = "cust_id"), inverseJoinColumns = @JoinColumn(name = "event_id"))
	private Set<EventMaster> events = new HashSet<EventMaster>();

	public Set<EventMaster> getEvents() {
		return events;
	}

	public void setEvents(Set<EventMaster> events) {
		this.events = events;
	}

}
