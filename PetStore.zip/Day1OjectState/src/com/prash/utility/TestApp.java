package com.prash.utility;

import com.prash.beans.Event;
import com.prash.beans.EventKey;
import com.prash.beans.Room;
import com.prash.dao.EventManager;
import com.prash.dao.RoomManager;

public class TestApp {

	/*	public static void main(String[] args) {
		RoomManager rm=new RoomManager();
		Room room=new Room();
		room.setCapacity(25);
		room.setLocation("MEPZ");
		room.setMachine_avl(true);
		room.setProj_avl(true);
		rm.AddRoom(room);
		
	} */
	
	public static void main(String[] args) 
	{
		RoomManager rm=new RoomManager();
		for(Room room:rm.GetAllRooms())
		{
			System.out.print(room.getRoomno()+" ");
			System.out.println(room.getCapacity());
		}
		
		
		//rm.updateRoom(1);
		//rm.DeleteRoom(2);
		//rm.roomEvict_clear(1, 2);
		rm.SessionClose(1);
		EventTestApp();
		
	}
	
	public static void EventTestApp()
	{
		EventManager eventManager=new EventManager();
		EventKey eventKey=new EventKey();
		eventKey.setEventId(2);
		eventKey.setTrainerId(249);
		
		Event event=new Event();
		event.setEventid(eventKey);
		event.setEventduration(5);
		event.setEventlocation("chennai");
		event.setEventname("My Hibe Training");
		eventManager.AddEvent(event);
	}
}
