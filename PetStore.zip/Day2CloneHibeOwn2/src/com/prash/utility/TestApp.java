package com.prash.utility;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.prash.beans.Course;
import com.prash.beans.Player;
import com.prash.beans.Team;
import com.prash.beans.Trainee;
import com.prash.dao.DaoManager;

public class TestApp {
public static void main(String[] args) {
	/*DaoManager dm=new DaoManager();
	Team tm=new Team();
	tm.setTname("CSK");
	List<Player> pl=new ArrayList<Player>();
	Player player=new Player();
	player.setPname("Dhoni");
	player.setTm(tm);
	pl.add(player);
	dm.AddTeam_Player(tm, pl);
	*/
	
	/*
	DaoManager dm=new DaoManager();
	for(Team team:dm.getAll_team_players())
	{
		System.out.println(team.getTname());
		
		for (Player player : team.getPlist()) {
		System.out.println(player.getPname());	
		}
	} */
	
	DaoManager dm=new DaoManager();
	List<Trainee> tlist=new ArrayList<Trainee>();
	List<Course> clist=new ArrayList<Course>();
	Trainee t12=new Trainee();
	t12.setTraineeName("Prashanth");
	tlist.add(t12);
	t12=new Trainee();
	t12.setTraineeName("Sekar");
	tlist.add(t12);
	Course c12=new Course();
	c12.setCourseName("Hibernate");
	clist.add(c12);
	
	
	dm.Add_Trainee_course(tlist, clist);
}
}
