package com.payment.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="cts_employee")
public class Employee extends CTS_Person{
@Column(name="emp_id")
	private int Emp_id;
@Column(name="name")
	private String name;
@Column(name="proj")
	private String project;
@Column(name="loc")
	private String location;

	public String getProject() {
	return project;
}
public void setProject(String project) {
	this.project = project;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
	public int getEmp_id() {
		return Emp_id;
	}
	public void setEmp_id(int emp_id) {
		Emp_id = emp_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	

}
