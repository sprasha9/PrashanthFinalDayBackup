package com.prash.utility;

import java.util.Date;



import com.prash.beans.Author;
import com.prash.beans.Book;
import com.prash.dao.DaoManager;

public class TestApp {
public static void main(String[] args) {
	DaoManager dm=new DaoManager();
	Book bk=new Book();
	bk.setName("Java Peogramming");
	bk.setDop(new Date(85, 05, 28));
	Author a1=new Author();
	a1.setAuthName("James Goasling");
	dm.AddBook_Author(bk, a1);
}
}
