package com.cts.booking.entity;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@DiscriminatorValue( value="E")
public class ExistingCustomer extends Customer{
    

}
