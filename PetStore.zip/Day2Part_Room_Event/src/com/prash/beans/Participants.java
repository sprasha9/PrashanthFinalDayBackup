package com.prash.beans;

public class Participants {

	private int part_id;
	private String part_name;
	private String pa_mailid;
	private Room room;
	public int getPart_id() {
		return part_id;
	}
	public void setPart_id(int part_id) {
		this.part_id = part_id;
	}
	public String getPart_name() {
		return part_name;
	}
	public void setPart_name(String part_name) {
		this.part_name = part_name;
	}
	public String getPa_mailid() {
		return pa_mailid;
	}
	public void setPa_mailid(String pa_mailid) {
		this.pa_mailid = pa_mailid;
	}
	public Room getRoom() {
		return room;
	}
	public void setRoom(Room room) {
		this.room = room;
	}
	
	
}
