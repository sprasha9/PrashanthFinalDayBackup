package com.prash.dao;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;





import org.hibernate.sql.Delete;

import com.prash.beans.Room;
import com.prash.resources.HibernateUtil;

public class RoomManager {
	
	private SessionFactory factory;
	private Session session;
	
	
	
	public RoomManager()
	{
		factory=HibernateUtil.GetFactory();
	}
	
	
	
public boolean AddRoom(Room room)
{
	boolean status=false;
	
	session=factory.openSession();
	session.beginTransaction();
	
	try{
		session.save(room);
		session.getTransaction().commit();
		status=true;
	}
	catch(HibernateException ex)
	{
		session.getTransaction().rollback();
	}
	return status;
	
}

public List<Room> GetAllRooms()
{
	session=factory.openSession();
	return session.createQuery("from Room").list();
}

//Update
public boolean updateRoom(int RoomNO)
{
	boolean status=false;
	session=factory.openSession();
	//Room room=(Room) session.get(Room.class, new Integer(4));
	Room room=(Room) session.get(Room.class, RoomNO);
	room.setCapacity(35);
	room.setMachine_avl(false);
	session.beginTransaction();
	try {
		//session.update(room);
		session.getTransaction().commit();
		status=true;
	} catch (Exception e) {
		// TODO: handle exception
		
		session.getTransaction().rollback();
	}
	session.close();
	
	
	return status;
	
}

//Delete---------------------------------------------------------------
public boolean DeleteRoom(int RoomNo) {
	boolean status=false;
	session=factory.openSession();
	//Room room=(Room) session.get(Room.class, new Integer(4));
	Room room=(Room) session.get(Room.class, RoomNo);
	session.beginTransaction();
	
	try {
		session.delete(room);
		session.getTransaction().commit();
		status=true;
	} catch (Exception e) {
		// TODO: handle exception
		
		session.getTransaction().rollback();
	}
	session.close();
	
	
	return status;
	
}

public boolean roomEvict_clear(int RoomNo1,int RoomNo2)
{
	boolean status=false;
	session=factory.openSession();
	Room rmobj1=(Room) session.get(Room.class, RoomNo1);
	Room rmobj2=(Room) session.get(Room.class, RoomNo2);
	
	//session.evict(rmobj2);
	session.clear();
	session.beginTransaction();
	rmobj1.setCapacity(150);
	rmobj2.setCapacity(200);
	session.getTransaction().commit();
	status=true;
	session.close();
	return status;
	
}

//Session Close--------------------------------------------------------------------
public boolean SessionClose(int RoomNo)
{
	boolean status=false;
	session=factory.openSession();
	Room room=(Room) session.get(Room.class, RoomNo);
	session.beginTransaction();
	session.close();
	
	room.setCapacity(67);
	Session session1=factory.openSession();
	session1.beginTransaction();
	Room room1=(Room) session1.get(Room.class,RoomNo);
	session1.merge(room);
	
	session1.getTransaction().commit();
	status=true;
	
	return status;
	
}
}
