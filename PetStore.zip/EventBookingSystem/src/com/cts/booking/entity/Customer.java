package com.cts.booking.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import com.cts.EventMaster;


@Entity
@Table(name="Customer_v1")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "type", discriminatorType = DiscriminatorType.STRING)
public class Customer implements Serializable{	
	
	@Id
	@Column(name="cust_id")
	protected int custId;

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	
	@ManyToMany(targetEntity = com.cts.EventMaster.class, cascade = {
		CascadeType.PERSIST, CascadeType.MERGE })
@JoinTable(name = "Bookingc", joinColumns = @JoinColumn(name = "cust_id"), inverseJoinColumns = @JoinColumn(name = "event_id"))
	private Set<EventMaster> events = new HashSet<EventMaster>();

public Set<EventMaster> getEvents() {
	return events;
}

public void setEvents(Set<EventMaster> events) {
	this.events = events;
}

	@Column(name="cust_name")
	protected String custName;
	@Column(name="cust_address")
	protected String custAddress;

}
