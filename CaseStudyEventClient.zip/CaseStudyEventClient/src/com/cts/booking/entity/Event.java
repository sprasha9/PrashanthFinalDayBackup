package com.cts.booking.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
@Entity
@Table(name="EVENT_MASTER")
@XmlRootElement
public class Event {
	//add mappings or annotations for the Customer entity class. 
	//Create Many-to Many association relationship between Customer and Event entity and 
	// hence add the collection properties accordingly
@Id
@Column(name="Event_ID")
	private int eventId;
@Column(name="Event_Name")
	private String eventName;
@Temporal(TemporalType.DATE)
@Column(name="Event_Date")
	private Date eventDate;
@Column(name="TICKETS_AVAILABLE")
	private int ticketsAvailable;
@OneToOne (cascade=CascadeType.ALL)
@JoinColumn(name="LOCATION_ID", unique= true, nullable=false)
	private Location location;


public int getEventId() {
	return eventId;
}
public void setEventId(int eventId) {
	this.eventId = eventId;
}
public String getEventName() {
	return eventName;
}
public void setEventName(String eventName) {
	this.eventName = eventName;
}
public Date getEventDate() {
	return eventDate;
}
public void setEventDate(Date eventDate) {
	this.eventDate = eventDate;
}
public int getTicketsAvailable() {
	return ticketsAvailable;
}
public void setTicketsAvailable(int ticketsAvailable) {
	this.ticketsAvailable = ticketsAvailable;
}
public Location getLocation() {
	return location;
}
public void setLocation(Location location) {
	this.location = location;
}

	



}
