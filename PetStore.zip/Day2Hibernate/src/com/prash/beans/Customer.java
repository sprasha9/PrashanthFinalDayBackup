package com.prash.beans;



import java.util.Date;

import javax.persistence.*;
@Entity
@Table(name="FlipCustomer")

public class Customer {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Customer_Id")
	private int customerid;
	@Column(name="Cus_Name")
	private String cusname;
	@Temporal(TemporalType.DATE)
	@Column(name="DOB")
	private Date cusdob;
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@OneToOne
	@JoinColumn(name="Home_Address")
	private Address address;
	
	public int getCustomerid() {
		return customerid;
	}
	
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	
	public String getCusname() {
		return cusname;
	}
	
	public void setCusname(String cusname) {
		this.cusname = cusname;
	}
	
	public Date getCusdob() {
		return cusdob;
	}
	
	public void setCusdob(Date cusdob) {
		this.cusdob = cusdob;
	}
	
}
