package com.payment.beans;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="debitcard")
//@DiscriminatorValue(value="DebitCardObject")
public class DebitCard extends Payment{
@Column(name="debitCardNo")
	private long debitCardNo;
@Column(name="dcCVV")
	private int dcCVV;
@Column(name="dcName")
	private String dcName;
@Column(name="dcExpDate")
	private Date dcExpDate;
	
	public long getDebitCardNo() {
		return debitCardNo;
	}
	public void setDebitCardNo(long debitCardNo) {
		this.debitCardNo = debitCardNo;
	}
	public int getDcCVV() {
		return dcCVV;
	}
	public void setDcCVV(int dcCVV) {
		this.dcCVV = dcCVV;
	}
	public String getDcName() {
		return dcName;
	}
	public void setDcName(String dcName) {
		this.dcName = dcName;
	}
	public Date getDcExpDate() {
		return dcExpDate;
	}
	public void setDcExpDate(Date dcExpDate) {
		this.dcExpDate = dcExpDate;
	}
	
	
}
