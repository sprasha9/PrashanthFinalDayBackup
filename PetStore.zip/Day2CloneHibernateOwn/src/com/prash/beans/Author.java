package com.prash.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name="Author")
public class Author {

	@Id
	@Column(name="Author_Id")
	@GeneratedValue(generator="gen")
	@GenericGenerator(name="gen",strategy="foreign",parameters=@Parameter(name="property",value="book"))
	private int AuthorId;
	@Column(name="Author_name")
	private String AuthName;
	@OneToOne
	@PrimaryKeyJoinColumn
	private Book book;
	public int getAuthorId() {
		return AuthorId;
	}
	public void setAuthorId(int authorId) {
		AuthorId = authorId;
	}
	public String getAuthName() {
		return AuthName;
	}
	public void setAuthName(String authName) {
		AuthName = authName;
	}
	public Book getBk() {
		return book;
	}
	public void setBk(Book bk) {
		this.book = bk;
	}
}
