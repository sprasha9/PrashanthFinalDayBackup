package com.cts.utill;

import org.hibernate.SessionFactory;

import com.cts.resources.HibernateUtil;

public class TestApp {
	public static void main(String[] args)
	{
		SessionFactory factory = HibernateUtil.getSessionFactory();
	}

}
