package com.prash.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.prash.beans.Address;
import com.prash.beans.Customer;
import com.prash.resources.HibernateUtil;

public class DaoManager {
	
	private SessionFactory factory;
	private Session session;
	
	public DaoManager()
	{
		factory=HibernateUtil.GetFactory();
	}
	
	
	public boolean AddCustomer_Adress(Customer customer,Address address)
	{
		boolean status=false;
		session=factory.openSession();
		session.beginTransaction();
		try {
			session.save(address);
			customer.setAddress(address);
			session.persist(customer);
			session.getTransaction().commit();
			status=true;
			
			
		} catch (HibernateException e) {
			// TODO: handle exception
			session.getTransaction().rollback();
		}
		return status;
		
	}
	
	
	public  Query GetAll()
	{
		session=factory.openSession();
		return session.createQuery("select customer.customerid,customer.cusname,address.AddStreet,address.Addcity from Customer customer inner join customer.address address");
	}
}
