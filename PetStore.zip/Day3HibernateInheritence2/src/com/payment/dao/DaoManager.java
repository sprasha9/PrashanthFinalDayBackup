package com.payment.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.payment.beans.Address;
import com.payment.beans.CTS_Person;
import com.payment.resources.HibernateUtil;

public class DaoManager {

	private SessionFactory factory;
	private Session session;
	private boolean status=false;
	
	public DaoManager()
	{
		factory=HibernateUtil.GetFactory();
		
	}
	
	public boolean AddPerson(CTS_Person person,Address address)
	{
		session=factory.openSession();
		session.beginTransaction();
		try {

			session.persist(address);
		person.setAdderss(address);
			session.persist(person);
			session.getTransaction().commit();
			status=true;
		} catch (HibernateException e) {
			// TODO: handle exception
			session.getTransaction().rollback();
		}
		return status;
	}
	
	
}
