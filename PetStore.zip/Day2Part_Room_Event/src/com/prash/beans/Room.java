package com.prash.beans;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="newroom")
public class Room {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="room_no")
	private int roomNo;

	private Event event;
	private List<Participants> pa_List;
	
	public List<Participants> getPa_List() {
		return pa_List;
	}
	public void setPa_List(List<Participants> pa_List) {
		this.pa_List = pa_List;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public Event getEvent() {
		return event;
	}
	public void setEvent(Event event) {
		this.event = event;
	}
	
}
