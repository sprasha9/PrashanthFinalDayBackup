package com.cts.booking.services;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.cts.booking.dao.BookingDao;
import com.cts.booking.entity.Location;
import com.cts.booking.entity.Message;




@Path("/locationService")
public class LocationService {
	@POST
	@Path("/AddLocation")
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
public Response AddCustomerService(Location location) {
		
		boolean bb=BookingDao.insertLocationData(location);
		Message message=new Message();
		message.setStatus("Not Added");
		if(bb)
		{
			message.setStatus("Added");
		}
return Response.status(200).header("Acess-control-Allow-Orgin", "*")
		.header("Access-Control-Allow-Headers","orgin,content-type,accept,authorization")
		.header("Access-Control-Allow-Credentials", true)
		.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
		.header("Access-Control-Max-Age","1209600" )
		.entity(message).build();
	}
	
	@GET
	@Path("/GetLocation")
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public Response getLocation()
	{
		GenericEntity<List<Location>> genentity=new GenericEntity<List<Location>>(BookingDao.getAll()){};
		return Response.status(200).header("Acess-control-Allow-Orgin", "*")
				.header("Access-Control-Allow-Headers","orgin,content-type,accept,authorization")
				.header("Access-Control-Allow-Credentials", true)
				.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS,HEAD")
				.header("Access-Control-Max-Age","1209600" )
				.entity(genentity).build();
				
		
				
	}
	
}
