package com.prash.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.prash.beans.Author;
import com.prash.beans.Book;
import com.prash.resources.HibernateUtil;

public class DaoManager {
private SessionFactory factory;
private Session session;

public DaoManager()
{
	factory=HibernateUtil.GetFactory();
}

public Boolean AddBook_Author(Book book,Author author)
{
	boolean status=false;
	session=factory.openSession();
	session.beginTransaction();
	try {
		author.setBk(book);
		book.setAuth(author);
		session.save(book);
		session.getTransaction().commit();
		status=true;
	} catch (Exception e) {
		// TODO: handle exception
	session.getTransaction().rollback();
	}
	
	
	return status;
	
}
}
