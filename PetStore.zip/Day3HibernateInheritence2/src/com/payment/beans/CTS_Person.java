package com.payment.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="cts_peson")
@Inheritance(strategy=InheritanceType.JOINED)
public class CTS_Person {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="aathar_no")
	private int aatharcardno;
@Column(name="name")
	private String name;
@OneToOne
@JoinColumn(name="Home_Address")
	private Address adderss;
	
	public int getAatharcardno() {
		return aatharcardno;
	}
	public void setAatharcardno(int aatharcardno) {
		this.aatharcardno = aatharcardno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAdderss() {
		return adderss;
	}
	public void setAdderss(Address adderss) {
		this.adderss = adderss;
	}

}
