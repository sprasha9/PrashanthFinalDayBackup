package com.prash.beans;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="Team")
public class Team {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="team_id")
	private int teamId;
@Column(name="team_name")
	private String tname;
@OneToMany(mappedBy="team",fetch=FetchType.LAZY,cascade=CascadeType.ALL)	
	private List<Player> plist;



	public int getTeamId() {
	return teamId;
}

public void setTeamId(int teamId) {
	this.teamId = teamId;
}

public String getTname() {
	return tname;
}

public void setTname(String tname) {
	this.tname = tname;
}

public List<Player> getPlist() {
	return plist;
}

public void setPlist(List<Player> plist) {
	this.plist = plist;
}

	
	
}
