package com.prash.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="FlipAddress")
public class Address {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="Address_Id")
	private int addressid;
@Column(name="Street",length=50)
	private String AddStreet;
@Column(name="Address_city")
	private String Addcity;
	
	public int getAddressid() {
		return addressid;
	}
	
	public void setAddressid(int addressid) {
		this.addressid = addressid;
	}
	
	public String getAddStreet() {
		return AddStreet;
	}
	
	public void setAddStreet(String addStreet) {
		AddStreet = addStreet;
	}
	
	public String getAddcity() {
		return Addcity;
	}
	
	public void setAddcity(String addcity) {
		Addcity = addcity;
	}
	
	
}
