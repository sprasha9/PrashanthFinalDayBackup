package com.prash.beans;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Event")
public class Event {
	@EmbeddedId
	private EventKey eventid;
	@Column(name="EventName")
	private String eventname;
	@Column(name="EventDuration")
	private int eventduration;
	@Column(name="EventLocation")
	private String eventlocation;
	public EventKey getEventid() {
		return eventid;
	}
	public void setEventid(EventKey eventid) {
		this.eventid = eventid;
	}
	public String getEventname() {
		return eventname;
	}
	public void setEventname(String eventname) {
		this.eventname = eventname;
	}
	public int getEventduration() {
		return eventduration;
	}
	public void setEventduration(int eventduration) {
		this.eventduration = eventduration;
	}
	public String getEventlocation() {
		return eventlocation;
	}
	public void setEventlocation(String eventlocation) {
		this.eventlocation = eventlocation;
	}
	
	
	

}
