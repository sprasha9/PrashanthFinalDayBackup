package com.cts.entities;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name="cts_newcustomer")
public class NewCustomer extends Customer{

}
